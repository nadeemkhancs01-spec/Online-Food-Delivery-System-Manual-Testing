# ONLINE FOOD DELIVERY SYSTEM — Manual Testing Project

## 1. Project Overview
This repository is a beginner-friendly manual software testing portfolio project for an **ONLINE FOOD DELIVERY SYSTEM**. It contains a professional test plan, test scenarios, 50+ manual test cases, an execution-report template, a bug-report template, and a PDF test-summary template.

**Execution state:** Pending. No working application URL or authorized test environment was provided in this task. Therefore, no live application testing is claimed.

## 2. Application Under Test
- **Application Name:** ONLINE FOOD DELIVERY SYSTEM
- **Application URL:** Not provided
- **Tester:** NADEEM KHAN
- **Testing Type:** Manual Functional Testing + UI Testing + Negative Testing + Regression Testing
- **Browser:** Google Chrome (planned environment; browser version not verified)

## 3. Testing Objective
To verify the functional behavior, validation, navigation, UI behavior, negative scenarios, and regression-critical flows of an online food delivery application when an authorized working test environment is available.

## 4. Testing Scope
Planned coverage includes registration, login/logout, home page, restaurant listing/search, food search, restaurant/menu/item details, cart operations, price calculation, delivery address, checkout, payment validation, order placement/confirmation/history, tracking/cancellation where supported, UI, navigation, error handling, negative testing, and regression testing.

Only features actually present in the application should be executed. Unsupported features must be marked Not Applicable or documented as unavailable.

## 5. Testing Types
- Functional testing
- UI testing
- Negative testing
- Boundary/validation testing
- Navigation testing
- Error-handling testing
- Regression testing

## 6. Test Environment
- Browser: Google Chrome (planned; exact version not verified)
- Operating System: Not verified
- Application version/build: Not provided
- Test URL: Not provided
- Test accounts: Not provided
- Payment environment: No live payment testing performed

## 7. Test Data and Test Accounts
The workbook contains safe fictional test-data guidance. No real credentials, personal information, or payment-card details are included. Authorized test credentials should be supplied by the application owner before execution.

## 8. Project Structure
```text
ONLINE-FOOD-DELIVERY-SYSTEM-Manual-Testing/
├── README.md
├── 01_Test_Plan/
│   └── Test_Plan.xlsx
├── 02_Test_Scenarios/
│   └── Test_Scenarios.xlsx
├── 03_Test_Cases/
│   └── Test_Cases.xlsx
├── 04_Test_Execution/
│   └── Test_Execution_Report.xlsx
├── 05_Bug_Reports/
│   └── Bug_Report.xlsx
├── 06_Screenshots/
│   ├── Login/
│   ├── Registration/
│   ├── Home/
│   ├── Restaurant/
│   ├── Search/
│   ├── Menu/
│   ├── Cart/
│   ├── Checkout/
│   └── Orders/
│   └── Bugs/
└── 07_Test_Summary/
    └── Test_Summary_Report.pdf
```

## 9. Test Scenarios
See `02_Test_Scenarios/Test_Scenarios.xlsx`. It contains 35 planned scenarios with priorities.

## 10. Test Cases
See `03_Test_Cases/Test_Cases.xlsx`. It contains 55 planned manual test cases covering positive, negative, boundary, UI, functional, and regression-oriented checks. All cases are initially **Not Executed**.

## 11. Test Execution Report
See `04_Test_Execution/Test_Execution_Report.xlsx`. It is prepared to record actual execution only. The current summary is **Pending** because no live tests have been executed.

## 12. Defect Reports
See `05_Bug_Reports/Bug_Report.xlsx`. No confirmed defect has been reported because no live execution was performed. Do not add a defect unless it is observed and reproducible.

## 13. Screenshots and Evidence
The screenshot directories are intentionally empty. No fabricated or AI-generated images are included. During authorized execution, save only real application evidence and use the test-case/bug IDs in filenames.

## 14. Test Execution Summary
Current state:
- Total planned test cases: 55
- Executed test cases: 0
- Passed: 0
- Failed: 0
- Blocked: 0
- Not Executed: 55
- Not Reproducible: 0
- Pass Percentage: N/A
- Fail Percentage: N/A

Percentages are N/A because no test cases have a final execution outcome.

## 15. Known Limitations
- No application URL was provided.
- No live execution was possible.
- Application features have not been verified.
- Operating system and Chrome version have not been verified.
- No screenshots were captured.
- No defects were confirmed.
- Payment and order placement were not performed.

## 16. Final Result
**Execution Pending.** This repository is a professional documentation/template baseline and does not claim completed live testing.

## 17. How to Use This Repository
1. Obtain the authorized application URL and test credentials.
2. Verify the application and available modules.
3. Update the Test Plan with verified environment details.
4. Execute only applicable test cases.
5. Record actual results and dates in the Execution Report.
6. Capture real screenshots where permitted.
7. Log only reproducible defects.
8. Update the PDF summary from actual execution data.
9. Review all IDs and evidence before publishing to GitHub.
10. Never commit passwords, tokens, private customer data, or payment information.

## 18. Tester Information
**Tester Name:** NADEEM KHAN

This repository is intended as a manual software testing portfolio project. It does not claim professional employment experience, certifications, or live testing that has not been performed.
